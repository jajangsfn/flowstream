<?php
$lang['object_goods'] = "Barang";
