<?php
$lang['placeholders_quantity'] = "Masukan Jumlah";

$lang['placeholders_add_name'] = "Masukan Nama";
$lang['placeholders_add_partner_code'] = "Masukan Kode Partner";

$lang['placeholders_add_goods_name'] = "Masukan Nama Barang";
$lang['placeholders_add_goods_barcode'] = "Masukan Nomor Barcode";
$lang['placeholders_add_goods_sku'] = "Masukan Kode SKU";
$lang['placeholders_add_goods_plu'] = "Masukan Kode PLU";
$lang['placeholders_add_goods_hpp'] = "Masukan HPP";
$lang['placeholders_add_goods_tax'] = "Masukan Pajak";
$lang['placeholders_add_goods_rekening_no'] = "Masukan Nomor Rekening";
