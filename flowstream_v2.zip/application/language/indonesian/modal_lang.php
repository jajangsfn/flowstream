<?php
$lang['modal_edit_goods'] = "Sunting Barang";
$lang['modal_delete_goods_description'] = "Anda akan menghapus Barang ini";
$lang['modal_delete_goods_subdescription'] = "Referensi barang ini pada data lain tidak akan ikut terhapus";

$lang['modal_add_partner'] = "Tambah Partner";