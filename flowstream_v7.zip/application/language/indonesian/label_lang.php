<?php
$lang['label_quantity'] = "Jumlah:";

$lang['label_add_name'] = "Nama:";
$lang['label_add_partner_code'] = "Kode Partner:";

$lang['label_add_goods_name'] = "Nama Barang:";
$lang['label_add_goods_barcode'] = "Barcode:";
$lang['label_add_goods_sku'] = "Kode SKU:";
$lang['label_add_goods_plu'] = "Kode PLU:";
$lang['label_add_goods_hpp'] = "Harga Pokok Penjualan:";
$lang['label_add_goods_tax'] = "Pajak:";
$lang['label_add_goods_rekening_no'] = "Nomor Rekening:";
