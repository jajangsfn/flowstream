<?php
$lang['menu_dashboard'] = "Dashboard";
$lang['menu_sales'] = "Penjualan";
$lang['menu_purchases'] = "Pembelian";
$lang['menu_inventory'] = "Inventori";
$lang['menu_finance'] = "Keuangan";
$lang['menu_setting_and_config'] = "Setting dan Konfigurasi";
