<script>
	$(document). ready( function() {
		$("#datatable").dataTable();
	});
</script>