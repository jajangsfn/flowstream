<button type="submit" class="btn btn-primary mr-2">
    Simpan
</button>