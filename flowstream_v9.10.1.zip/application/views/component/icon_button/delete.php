<button type="button" class="btn btn-icon btn-sm btn-light-danger" data-toggle="modal" data-target="#delete_<?= $id ?>">
    <i class="flaticon2-trash"></i>
</button>