<?php
$lang['help_quantity'] = "Masukan jumlah";

$lang['help_add_name'] = "Masukan nama";
$lang['help_add_partner_code'] = "Masukan kode partner";

$lang['help_add_goods_name'] = "Masukan nama barang";
$lang['help_add_goods_barcode'] = "Masukan angka pada barcode";
$lang['help_add_goods_sku'] = "Masukan kode <em>Stock Keeping Unit</em>";
$lang['help_add_goods_plu'] = "Masukan kode <em>Price Look-up</em>";
$lang['help_add_goods_hpp'] = "Masukan Harga Pokok Penjualan";
$lang['help_add_goods_tax'] = "Masukan Pajak";
$lang['help_add_goods_rekening_no'] = "Masukan Nomor Rekening";