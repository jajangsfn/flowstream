<div class="row d-flex justify-content-center">
    <div class="col-md-2">
        <a href="#" class="h4 text-white text-hover-white text-center">
            <div class="card card-stretch card-custom gutter-b bg-primary">
                <div class="card-body d-flex justify-content-center align-items-center">
                    Parameter Pembelian
                </div>
            </div>
        </a>
    </div>
    <div class="col-md-2">
        <a href="#" class="h4 text-white text-hover-white text-center">
            <div class="card card-stretch card-custom gutter-b bg-primary">
                <div class="card-body d-flex justify-content-center align-items-center">
                    Parameter Penjualan
                </div>
            </div>
        </a>
    </div>
    <div class="col-md-2">
        <a href="#" class="h4 text-white text-hover-white text-center">
            <div class="card card-stretch card-custom gutter-b bg-primary">
                <div class="card-body d-flex justify-content-center align-items-center">
                    Parameter Barang
                </div>
            </div>
        </a>
    </div>
    <div class="col-md-2">
        <a href="#" class="h4 text-white text-hover-white text-center">
            <div class="card card-stretch card-custom gutter-b bg-primary">
                <div class="card-body d-flex justify-content-center align-items-center">
                    Parameter Inventori
                </div>
            </div>
        </a>
    </div>
    <div class="col-md-2">
        <a href="<?= current_url() ?>/keuangan" class="h4 text-white text-hover-white text-center">
            <div class="card card-stretch card-custom gutter-b bg-primary">
                <div class="card-body d-flex justify-content-center align-items-center">
                    Parameter Keuangan
                </div>
            </div>
        </a>
    </div>
</div>