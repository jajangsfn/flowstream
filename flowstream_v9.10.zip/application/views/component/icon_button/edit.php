<button type="button" class="btn btn-icon btn-sm btn-light-success" data-toggle="modal" data-target="#edit_<?= $id ?>">
    <i class="flaticon2-pen"></i>
</button>